import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='ratokeshi',
    application_name='aws-python-bravo',
    app_uid='Xd3JsfDWtRBNbzcnvN',
    org_uid='cS3zgzgTmxM1z4qwh5',
    deployment_uid='6f7ceeed-21bd-46ae-b745-139358ddfdaa',
    service_name='aws-python-bravo',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.1.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-python-bravo-dev-hello', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.hello')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
